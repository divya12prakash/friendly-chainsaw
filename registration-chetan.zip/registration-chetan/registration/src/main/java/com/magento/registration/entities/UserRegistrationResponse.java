package com.magento.registration.entities;

import lombok.Getter;
import lombok.Setter;

/**
 * This class provides the sample response to the
 * user if registration was success/failure
 */

@Getter
@Setter
public class UserRegistrationResponse {

    /**
     * boolean to indicate of registration
     * was successful
     */
    private boolean isRegistrationSucces;

    /**
     * Optional message to the user
     * if any
     */
    private String messageToUser;
}
