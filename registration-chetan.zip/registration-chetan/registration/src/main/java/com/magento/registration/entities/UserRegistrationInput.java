package com.magento.registration.entities;

import lombok.Getter;
import lombok.Setter;

/**
 * This class is the sample message that
 * will be received as part of user registration
 */

@Getter
@Setter
public class UserRegistrationInput {

    /**
     * success url declaration
     */
    private String successUrl;

    /**
     * error url declaration
     */
    private String errorUrl;

    /**
     * form key declaration
     */
    private String formKey;
    /**
     * first name declaration
     */
    private String firstName;

    /**
     * middle name declaration
     */
    private String middleName;

    /**
     * last name declaration
     */
    private String lastName;

    /**
     * email declaration
     */
    private String email;

    /**
     * password declaration
     * Used String data type
     * for simplicity
     */
    private String password;

    /**
     * password declaration
     * Used String data type
     * for simplicity
     */
    private String passwordConfirmation;
}
