package com.magento.registration.service;

import com.magento.registration.entities.UserRegistrationInput;
import com.magento.registration.entities.UserRegistrationResponse;
import org.springframework.http.ResponseEntity;

/**
 * This interface exposes the methods to
 * call rest api of Magento server and
 * register the user
 */

public interface UserRegistrationService {

    /**
     * This method will be used to register
     * the user on Magento server
     * @return UserRegistrationResponse
     */
    ResponseEntity registerUser(UserRegistrationInput userRegistrationInput);
}
